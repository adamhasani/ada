import fs from 'fs'
import path from 'path'

// Perintah-perintah UTAMA yang akan ditampilkan
const COMMANDS_TO_SHOW = [
    // Tugas
    'newtugas', 'listtugas', 'upcoming', 'hapustugas', 'edittugas',
    // Catatan
    'catat', 'hapuscatat', 'caricatatan', 'shownote' 
] 

// [ Bagian import menuCh, menuDoc, menuteks, menuThumb3, configPath, dbPath, more, readmore, dan handlers lainnya tetap sama ]
import menuCh from '../@set/setMenu-1.js'
import menuDoc from '../@set/setMenu-2.js'
import menuteks from '../@set/setMenu-3.js' // 👈 Handler Teks Sederhana
import menuThumb3 from '../@set/setMenu-4.js'

const configPath = new URL('../../toolkit/set/config.json', import.meta.url).pathname,
      dbPath = new URL('../../toolkit/db/database.json', import.meta.url).pathname,
      more = String.fromCharCode(8206),
      readmore = more.repeat(4e3 + 1),
      handlers = { 1: menuCh, 2: menuDoc, 3: menuteks, 4: menuThumb3 }

const loadConfig = () => JSON.parse(fs.readFileSync(configPath, 'utf-8'))
      
const countPlugins = () => Object.values(global.plugins).filter(p => !(p.__path && p.__path.includes(path.join('plugins', '@set')))).length

function buildMenu(sender, prefix) {
  
  // --- A. BAGIAN HEADER ---
  let txt = `Halo *${sender}*, Saya adalah Mas Ngopi. Berikut daftar fitur untuk mengelola tugas dan catatan grup:\n\n`;
  txt += `${readmore}`; 
  // --- AKHIR BAGIAN HEADER ---

  // --- B. LOGIKA: FILTER DAN TAMPILKAN COMMANDS ---
  
  const filteredCommands = {}
  
  for (const pluginKey in global.plugins) {
    const plugin = global.plugins[pluginKey];
    const tags = plugin.tags || 'Utilitas Umum'; 
    const commandList = Array.isArray(plugin.command) ? plugin.command : [plugin.command];
    
    const mainCommand = commandList.find(cmd => COMMANDS_TO_SHOW.includes(cmd));
    
    if (mainCommand) {
        // Kategorisasi menjadi Tugas atau Catatan
        const tag = (tags.includes('Tugas Menu') || mainCommand.includes('tugas')) 
            ? '🗓️ Manajemen Tugas' 
            : '📝 Catatan & Pencarian'; 
        
        (filteredCommands[tag] ||= new Set()).add(mainCommand);
    }
  }

  // Fungsi untuk memformat commands
  const formatSectionCommands = (title, cmds) => {
      let s = `═╣ ${title} ╠═\n`
      
      Array.from(cmds).sort().forEach(c => {
          const originalPlugin = Object.values(global.plugins).find(p => 
              p.command && 
              (Array.isArray(p.command) ? p.command.includes(c) : p.command === c)
          );
          const prem = originalPlugin?.premium ? ' *[ premium ]*' : ''
          s += `▨ ${prefix}${c}${prem}\n`
      })
      return s + `════════════════\n\n`
  }

  // Menambahkan ke teks menu, diurutkan agar Tugas di atas
  const sortedCategories = Object.keys(filteredCommands).sort((a, b) => {
      if (a.includes('Tugas')) return -1;
      if (b.includes('Tugas')) return 1;
      return 0;
  });

  for (const cat of sortedCategories) {
      txt += formatSectionCommands(cat, filteredCommands[cat]);
  }
  
  // Fallback
  if (sortedCategories.length === 0) {
      txt += formatSectionCommands('Fitur Tugas & Catatan', new Set([`Tidak ditemukan perintah Tugas atau Catatan.`]));
  }

  // --- C. FOOTER KHUSUS (VERSI AWAM & SEDERHANA) ---
  txt += `═╣ 🚀 Tips Cepat Mas Ngopi Data ╠═\n`
  // Teks yang sudah disederhanakan:
  txt += `▨ 📝 Butuh tempat simpan cepat? Balas pesan apa saja dengan ${prefix}catat\n`
  txt += `▨ 🔍 Cari catatan yang sudah pernah disimpan dengan ${prefix}caricatatan [kata kunci]\n`
  txt += `▨ 🗓️ Cek tugas yang deadline HARI INI: ${prefix}upcoming\n\n`
  txt += `Semoga harimu produktif dan bebas deadline!`
  // --- AKHIR FOOTER KHUSUS ---

  return txt
}

const menuModule = {
  name: 'menu',
  command: ['menu', 'menuall'],
  tags: 'Info Menu',
  desc: 'Menampilkan menu tugas dan catatan.',
  prefix: !0,

  run: async (conn, msg, ctx) => {
    const config = loadConfig()
    // 🚨 PASTIKAN DI SINI MENGGUNAKAN HANDLER MODE 3 (menuteks)
    const handler = handlers[config.menuSetting.setMenu] 
    
    if (!handler) return conn.sendMessage(ctx.chatInfo.chatId, { text: `Mode menu tidak valid. Gunakan setmenu ${Object.keys(handlers).join(' atau ')}` }, { quoted: msg })
    try {
      const category = null 
      return handler.run(conn, msg, ctx, buildMenu(ctx.chatInfo.pushName, ctx.prefix))
    } catch (e) {
      console.error('Menu error:', e)
      await conn.sendMessage(ctx.chatInfo.chatId, { text: 'Terjadi kesalahan saat membuka menu.' }, { quoted: msg })
    }
  }
}

export default { ...menuModule, handlers }
