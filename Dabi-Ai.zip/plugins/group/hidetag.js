export default {
  name: 'hidetag',
  command: ['hidetag', 'h'],
  tags: 'Group Menu',
  desc: 'Tag semua anggota grup (Hanya Admin/Owner). Bisa dengan reply pesan.',
  prefix: !0,
  owner: !1, 
  premium: !1,

  run: async (conn, msg, {
    chatInfo,
    prefix,
    commandText,
    args
  }) => {
    const { chatId, senderId, isGroup, senderNumber } = chatInfo
    
    if (!isGroup) return conn.sendMessage(chatId, { text: 'Perintah ini hanya bisa digunakan dalam grup!' }, { quoted: msg })

    // --- OTORISASI (Sudah diperbaiki dan stabil) ---
    const hardcodedNumber = '6287751121269';
    const isHardcodedOwner = (senderNumber === hardcodedNumber) || (senderId.startsWith(hardcodedNumber));
    const { userAdmin } = await exGrup(conn, chatId, senderId) 
    if (!isHardcodedOwner && !userAdmin) {
        return conn.sendMessage(chatId, { text: 'Perintah ini hanya untuk *Owner Bot* atau *Admin Grup*!' }, { quoted: msg })
    }
    // --- AKHIR OTORISASI ---


    // --- LOGIKA PESAN (Reply Sederhana, terbukti berfungsi) ---
    let textToSend = args.join(' ');
    
    if (!textToSend) { 
        let repliedText = '';
        if (msg.quoted) {
            repliedText = msg.quoted.text || msg.quoted.caption || '';
        }
        if (!repliedText) {
            const quotedMsg = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
            if (quotedMsg) {
                repliedText = 
                    quotedMsg.conversation || 
                    quotedMsg.extendedTextMessage?.text || 
                    quotedMsg.imageMessage?.caption ||
                    quotedMsg.videoMessage?.caption ||
                    '';
            }
        }
        textToSend = repliedText;
    }

    if (!textToSend) {
        return conn.sendMessage(chatId, { text: `Harap masukkan teks atau *balas (reply) pesan* yang ingin Anda teruskan.` }, { quoted: msg })
    }
    
    // --- ⬇️ PERBAIKAN LOGIKA TAGGING ⬇️ ---
    try {
      const meta = await getMetadata(chatId, conn);
      
      if (!meta) {
          return conn.sendMessage(chatId, { text: 'Gagal mengambil data grup. Tidak dapat melakukan tagging.' }, { quoted: msg });
      }

      // Ambil daftar peserta, pastikan formatnya adalah JID lengkap (mis. 628...@s.whatsapp.net)
      const participantsJids = meta.participants.map(p => p.id);
      
      if (participantsJids.length === 0) {
          return conn.sendMessage(chatId, { text: 'Gagal menemukan daftar peserta grup. Tagging dibatalkan.' }, { quoted: msg });
      }

      // Kirim pesan dengan array JID di properti 'mentions'
      await conn.sendMessage(chatId, { 
          text: textToSend, 
          mentions: participantsJids 
      }, { quoted: msg });
      
    } catch (err) {
      console.error(err),
      conn.sendMessage(chatId, { text: 'Gagal mengirim pesan atau melakukan tagging.' }, { quoted: msg })
    }
  }
}
