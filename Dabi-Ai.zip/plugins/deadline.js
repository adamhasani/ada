import fs from "fs";
import path from "path";

// 1. FUNGSI PENDUKUNG
function formatTimeRemaining(ms) {
    const totalMinutes = Math.floor(ms / (1000 * 60));
    const totalHours = Math.floor(totalMinutes / 60);
    const days = Math.floor(totalHours / 24);
    
    const hours = totalHours % 24; 
    const minutes = totalMinutes % 60; 

    let output = '';
    if (days > 0) output += `${days} hari`;
    if (hours > 0) output += (output ? ', ' : '') + `${hours} jam`;
    if (minutes > 0) output += (output ? ', ' : '') + `${minutes} menit`;
    
    return output || 'Kurang dari 1 menit';
}

// 2. KONSTANTA GLOBAL (Harus aman di level module)
const MS_IN_7_DAYS = 7 * 24 * 60 * 60 * 1000; 
const ZWS = '\u200b'; 

// 🚨 NOMOR TELEPON YANG DIIZINKAN (Whitelist)
const ALLOWED_NUMBERS = [
    '6287751121269',  
    '6289508712182',  
    '6282313085883'
]; 


export default {
    name: "alertdeadline",
    command: ["alertdeadline", "umumkandeadline", "tagdeadline"],
    tags: "Tugas Menu", 
    desc: "Mengumumkan tugas yang jatuh tempo dalam 7 hari ke depan ke seluruh grup (Hanya untuk pengguna tertentu).",
    prefix: !0,
    owner: !1, 

    run: async (conn, msg, { chatInfo, isGroup, prefix }) => {
        const { chatId, senderId, senderNumber } = chatInfo;

        // ⚠️ DEKLARASI PATH PINDAH KE SINI
        // Asumsi variabel 'dirname' tersedia di scope ini atau di global
        const deadlinePath = path.join(dirname, "./db/deadlines.json"); 

        // 1. Cek Grup
        if (!isGroup) {
            return conn.sendMessage(chatId, { text: 'Perintah ini hanya bisa digunakan dalam grup!' }, { quoted: msg });
        }
        
        // 2. Cek Izin (Whitelist & Owner)
        const isAuthorized = ALLOWED_NUMBERS.includes(senderNumber);
        const isOwner = Array.isArray(global.ownerNumber) && global.ownerNumber.includes(senderNumber);

        if (!isAuthorized && !isOwner) {
             return conn.sendMessage(chatId, { text: '❌ Anda tidak memiliki izin untuk menggunakan perintah ini. Perintah ini hanya untuk *Maintainer*.' }, { quoted: msg });
        }
        
        // --- Logika Utama ---
        try {
            // Cek Database
            if (!fs.existsSync(deadlinePath)) {
                return conn.sendMessage(chatId, { text: `⚠️ Database Tugas Belum Ditemukan! Path: ${deadlinePath}` }, { quoted: msg });
            }

            const data = fs.readFileSync(deadlinePath);
            let deadlines = JSON.parse(data);
            const taskNames = Object.keys(deadlines);
            const now = new Date();

            // 3. Filter Tugas yang Akan Datang (7 hari)
            const tasksArray = taskNames
                .map(name => ({ name, ...deadlines[name] }))
                .filter(task => {
                    const deadlineTime = new Date(task.deadline).getTime();
                    const diffMs = deadlineTime - now.getTime();
                    return diffMs > 0 && diffMs <= MS_IN_7_DAYS; 
                })
                .sort((a, b) => new Date(a.deadline) - new Date(b.deadline)); 

            if (tasksArray.length === 0) {
                return conn.sendMessage(chatId, { text: `😎 Tidak ada tugas mendesak yang perlu diumumkan saat ini.` }, { quoted: msg });
            }

            // 4. Buat Teks Pengumuman
            let listText = "🚨 *PERINGATAN DEADLINE MENDESAK!* 🚨\n\n";
            tasksArray.forEach((task, index) => {
                const deadlineDate = new Date(task.deadline);
                const countdownText = formatTimeRemaining(deadlineDate.getTime() - now.getTime());
                
                listText += `*${index + 1}. ${task.name}*\n`;
                listText += `   🗓️ Deadline: ${deadlineDate.toLocaleDateString('id-ID')} (${countdownText})\n`;
                if (task.description) {
                    const cleanDesc = task.description.replace(/\n/g, ' ').substring(0, 50); 
                    listText += `   📋 Deskripsi: ${cleanDesc}${task.description.length > 50 ? '...' : ''}\n`;
                }
                listText += `\n`;
            });

            // 5. Ambil daftar peserta grup (getMetadata)
            const meta = await getMetadata(chatId, conn); 
            const participantsToMention = meta.participants.map(p => p.id);

            // 6. Kirim pesan pengumuman & Hidetag
            await conn.sendMessage(chatId, { text: listText });

            if (participantsToMention.length > 0) {
                await conn.sendMessage(chatId, {
                    text: ZWS,
                    mentions: participantsToMention 
                });
            }

        } catch (e) {
            console.error('Error alertdeadline:', e);
            conn.sendMessage(chatId, { text: `❌ Gagal mengumumkan! Error: ${e.message}. Cek log konsol Anda.` }, { quoted: msg });
        }
    }
};
