import fs from "fs";
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';        

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename); 

const deadlinePath = join(__dirname, "../db/deadlines.json"); 

// Konstanta 8 hari untuk pengecekan (tasks dalam 7 hari)
const MS_IN_7_DAYS = 7 * 24 * 60 * 60 * 1000; 
const MS_IN_8_DAYS = 8 * 24 * 60 * 60 * 1000; 
// ZWS dihapus karena tidak digunakan lagi


// [ FUNGSI HELPER HARUS DISALIN KE SINI ATAU DIIMPOR DARI FILE LAIN ]
// *****************************************************************
function formatTimeRemaining(ms) {
    const totalMinutes = Math.floor(ms / (1000 * 60));
    const totalHours = Math.floor(totalMinutes / 60);
    const days = Math.floor(totalHours / 24);
    
    const hours = totalHours % 24; 
    const minutes = totalMinutes % 60; 

    let output = '';
    if (days > 0) output += `${days} hari`;
    if (hours > 0) output += (output ? ', ' : '') + `${hours} jam`;
    if (minutes > 0) output += (output ? ', ' : '') + `${minutes} menit`;
    
    return output || 'Kurang dari 1 menit';
}
// *****************************************************************

/**
 * Fungsi utama checker. Dipanggil setiap hari pada pukul 21:00.
 */
export default async function deadlineChecker(conn, getMetadata) {
    if (!fs.existsSync(deadlinePath)) return;

    try {
        const data = fs.readFileSync(deadlinePath);
        let deadlines = JSON.parse(data);
        const now = new Date();
        let updatedDeadlines = { ...deadlines };
        let hasChanges = false;
        
        const tasksToAnnounce = [];

        for (const taskName in deadlines) {
            const task = deadlines[taskName];
            const deadlineTime = new Date(task.deadline).getTime();
            const diffMs = deadlineTime - now.getTime();
            
            // 1. Pengecekan Tugas Kedaluwarsa (Pembersihan Otomatis)
            if (diffMs < 0 && Math.abs(diffMs) >= MS_IN_8_DAYS) { 
                 delete updatedDeadlines[taskName];
                 hasChanges = true;
                 continue;
            }

            // 2. Pengecekan Pengumuman Harian (Tugas yang akan jatuh tempo dalam 7 hari)
            if (diffMs > 0 && diffMs <= MS_IN_7_DAYS && !task.reminded_h7d) {
                 tasksToAnnounce.push({ name: taskName, ...task });
            }
        }
        
        // --- PROSES PENGUMUMAN ---
        if (tasksToAnnounce.length > 0) {
            
            // Mengelompokkan tugas berdasarkan chat (agar tidak mengirim ke chat yang salah)
            const tasksByChat = tasksToAnnounce.reduce((acc, task) => {
                (acc[task.addedBy] = acc[task.addedBy] || []).push(task);
                return acc;
            }, {});

            for (const chatId in tasksByChat) {
                const chatTasks = tasksByChat[chatId];
                
                try {
                    let listText = "🚨 *PENGUMUMAN DEADLINE OTOMATIS (7 HARI)!* 🚨\n\n";

                    chatTasks.sort((a, b) => new Date(a.deadline) - new Date(b.deadline)).forEach((task, index) => {
                        const deadlineDate = new Date(task.deadline);
                        const countdownText = formatTimeRemaining(deadlineDate.getTime() - now.getTime());
                        
                        listText += `*${index + 1}. ${task.name}*\n`;
                        listText += `   🗓️ Deadline: ${deadlineDate.toLocaleDateString('id-ID', { dateStyle: 'full', timeStyle: 'short' })} (Sisa: ${countdownText})\n`;
                        if (task.description) {
                            listText += `   📋 Deskripsi: ${task.description.substring(0, 50)}${task.description.length > 50 ? '...' : ''}\n`;
                        }
                        listText += `\n`;
                        
                        // Tandai tugas agar tidak diingatkan lagi
                        updatedDeadlines[task.name].reminded_h7d = true;
                        hasChanges = true;
                    });
                    
                    // 1. Kirim pesan pengumuman (Hanya Teks)
                    await conn.sendMessage(chatId, { text: listText });

                } catch (e) {
                    console.error(`[FAIL-SENDING] Gagal kirim notif ke chat ${chatId}: ${e.message}`);
                    // Jika gagal kirim, kita biarkan flag 'reminded_h7d' tetap false
                }
            }
        }

        if (hasChanges) {
            fs.writeFileSync(deadlinePath, JSON.stringify(updatedDeadlines, null, 2));
        }

    } catch (err) {
        console.error(`[SCHEDULER-CRASH] Error di fungsi utama: ${err.message}`);
    }
}
