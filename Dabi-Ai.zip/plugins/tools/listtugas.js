import fs from "fs";
import path from "path";

// ⚠️ Pastikan 'dirname' sudah terdefinisi dengan benar di file utama Anda.
// Jika file ini ada di folder 'plugins', 'dirname' mungkin perlu '..'.
// Asumsi 'dirname' adalah root folder bot Anda.
const deadlinePath = path.join(global.dirname, "./db/deadlines.json"); // Menggunakan global.dirname jika ada, atau sesuaikan path

// Fungsi helper yang sama untuk menghitung dan memformat sisa waktu
function formatTimeRemaining(ms) {
    const totalSeconds = Math.floor(ms / 1000);
    const totalMinutes = Math.floor(totalSeconds / 60);
    const totalHours = Math.floor(totalMinutes / 60);
    const days = Math.floor(totalHours / 24);
    
    const hours = totalHours % 24; 
    const minutes = totalMinutes % 60; 

    let output = '';
    if (days > 0) output += `${days} hari`;
    if (hours > 0) output += (output ? ', ' : '') + `${hours} jam`;
    if (minutes > 0 && days === 0) output += (output ? ', ' : '') + `${minutes} menit`; // Hanya tampilkan menit jika < 1 hari
    
    if (output === '' && totalSeconds > 0) return `${totalSeconds} detik`; // Lebih baik dari 'Kurang dari 1 menit'
    return output || 'Tepat Waktu';
}

export default {
  name: "listtugas",
  command: ["listtugas", "deadlinelist", "listdeadline","list","tugas"],
  tags: "Tugas Menu", 
  desc: "Menampilkan daftar semua tugas yang terdaftar beserta deadlinenya.",
  prefix: !0,
  owner: !1, 
  premium: !1,

  run: async (conn, msg, { chatInfo, prefix }) => {
    const { chatId } = chatInfo;
    
    try {
      if (!fs.existsSync(deadlinePath)) {
        return conn.sendMessage(chatId, { text: `⚠️ *Database Tugas Belum Ditemukan!*\n\nCoba tambahkan tugas minimal 1x dengan *${prefix}newtugas*.` }, { quoted: msg });
      }

      const data = fs.readFileSync(deadlinePath);
      if (data.toString().trim().length === 0) {
          return conn.sendMessage(chatId, { text: `⚠️ *Database Tugas Kosong!* File *deadlines.json* ada, tapi kosong. Pastikan isinya *{}*.` }, { quoted: msg });
      }
      
      const deadlines = JSON.parse(data);
      const taskNames = Object.keys(deadlines);

      if (taskNames.length === 0) {
        return conn.sendMessage(chatId, { text: `🥳 Tidak ada tugas yang terdaftar saat ini!` }, { quoted: msg });
      }
      
      const now = new Date();
      const tasksArray = taskNames.map(name => ({ name, ...deadlines[name] }));
      tasksArray.sort((a, b) => new Date(a.deadline) - new Date(b.deadline));
      
      // --- LOGIKA BARU DIMULAI DI SINI ---

      // 1. Pisahkan tugas kadaluwarsa dan aktif
      const expiredTasks = tasksArray.filter(t => new Date(t.deadline).getTime() <= now.getTime());
      const activeTasks = tasksArray.filter(t => new Date(t.deadline).getTime() > now.getTime());

      let listText = "📅 *DAFTAR TUGAS ANDA*\n*(Diurutkan berdasarkan Deadline)*\n";

      // 2. Tampilkan bagian Kedaluwarsa jika ada
      if (expiredTasks.length > 0) {
          listText += "\n🔴 **KEDALUWARSA**\n";
          expiredTasks.forEach(task => {
              const deadlineDate = new Date(task.deadline);
              const timeDifferenceMs = deadlineDate.getTime() - now.getTime();
              const countdownText = `Telah Lewat: ${formatTimeRemaining(Math.abs(timeDifferenceMs))}`;
              
              listText += `\n* *${task.name}*\n`; // Pakai bullet point
              listText += `    * *Deadline:* _${deadlineDate.toLocaleString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' })}_\n`;
              listText += `    * *Status:* (${countdownText})\n`;
              if (task.description) {
                  listText += `    * *Deskripsi:* ${task.description}\n`;
              }
          });
          listText += "\n---\n"; // Pemisah bagian
      }

      // 3. Kelompokkan tugas aktif berdasarkan tanggal
      const groupedTasks = new Map();
      activeTasks.forEach(task => {
          const deadlineDate = new Date(task.deadline);
          // Buat Kunci Grup (e.g., "Selasa, 11 November 2025")
          const dateKey = deadlineDate.toLocaleDateString('id-ID', {
              weekday: 'long',
              day: 'numeric',
              month: 'long',
              year: 'numeric'
          }); 
          
          if (!groupedTasks.has(dateKey)) {
              groupedTasks.set(dateKey, []);
          }
          groupedTasks.get(dateKey).push(task);
      });

      // 4. Tampilkan tugas aktif yang sudah dikelompokkan
      let activeTaskCounter = 1; // Penomoran untuk tugas aktif
      
      if (groupedTasks.size === 0 && expiredTasks.length > 0) {
          listText += "\n🟢 *Semua tugas aktif sudah selesai!*";
      }

      groupedTasks.forEach((tasksOnDate, dateKey) => {
          // Header Tanggal Grup
          listText += `\n🟢 **${dateKey.toUpperCase()}**\n`;
          
          tasksOnDate.forEach((task) => {
              const deadlineDate = new Date(task.deadline);
              const timeDifferenceMs = deadlineDate.getTime() - now.getTime();
              const countdownText = `Sisa: ${formatTimeRemaining(timeDifferenceMs)}`;

              listText += `\n*${activeTaskCounter}. ${task.name}*\n`; 
              listText += `    * *Sisa Waktu:* _${countdownText}_\n`;
              if (task.description) {
                  listText += `    * *Deskripsi:* ${task.description}\n`;
              }
              activeTaskCounter++;
          });
          
          listText += "\n---\n"; // Pemisah antar grup tanggal
      });

      // 5. Buat Footer
      const totalActive = activeTaskCounter - 1;
      
      // Hapus pemisah '---' terakhir agar rapi
      if (listText.endsWith("\n---\n")) {
          listText = listText.substring(0, listText.length - 5);
      }

      listText += `\n\n_Total ${totalActive} tugas aktif terdaftar._`;
      
      // --- LOGIKA BARU BERAKHIR DI SINI ---

      return conn.sendMessage(chatId, { text: listText }, { quoted: msg });

    } catch (err) {
      // 🚨 Pesan Error Eksplisit untuk Debugging
      console.error("Error listtugas:", err);
      return conn.sendMessage(chatId, { 
          text: `❌ *ERROR PARSING DATA!* ❌\n\nDatabase tugas mungkin rusak. Coba cek isi *deadlines.json*.\nDetail Error:\n${err.message}` 
      }, { quoted: msg });
    }
  }
};
