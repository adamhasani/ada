import fs from "fs";
import path from "path";

// Pastikan path database sama dengan yang digunakan di plugin lain
const deadlinePath = path.join(dirname, "./db/deadlines.json");

export default {
  name: "hapustugas",
  command: ["hapustugas", "deldeadline", "removetugas"],
  tags: "Tugas Menu", 
  desc: "Menghapus tugas yang terdaftar berdasarkan nama tugas.",
  prefix: !0,
  owner: !1, 
  premium: !1,
  
  // Format penggunaan command
  example: "Format: %prefix%hapustugas [Nama Tugas yang Ingin Dihapus]",

  run: async (conn, msg, {
    chatInfo,
    prefix,
    args
  }) => {
    const { chatId } = chatInfo;
    const taskToDelete = args.join(" ").trim(); // Ambil seluruh input setelah command

    // 1. Validasi Input
    if (!taskToDelete) {
      return conn.sendMessage(chatId, { 
        text: `⚠️ *Nama Tugas Belum Dimasukkan.*\n\nMohon masukkan nama tugas yang ingin Anda hapus.\nContoh: *${prefix}hapustugas Tugas Matematika*` 
      }, { quoted: msg });
    }

    try {
      // 2. Cek Keberadaan Database
      if (!fs.existsSync(deadlinePath)) {
        return conn.sendMessage(chatId, { 
          text: `⚠️ *Database Tugas Belum Ditemukan!*\n\nTidak ada tugas yang terdaftar untuk dihapus.` 
        }, { quoted: msg });
      }

      const data = fs.readFileSync(deadlinePath);
      let deadlines = JSON.parse(data);
      const taskNames = Object.keys(deadlines);

      // 3. Cari Tugas (Case-Insensitive)
      // Cari nama tugas yang persis sama (mengabaikan kapitalisasi)
      const foundTaskName = taskNames.find(name => 
          name.toLowerCase() === taskToDelete.toLowerCase()
      );
      
      // Jika tugas tidak ditemukan
      if (!foundTaskName) {
        let notFoundMessage = `❌ *Tugas Tidak Ditemukan.*\n\nNama tugas: *${taskToDelete}* tidak ada dalam daftar.`;
        
        // Tampilkan 5 tugas teratas sebagai hint jika daftar tidak terlalu panjang
        if (taskNames.length > 0 && taskNames.length <= 10) {
            notFoundMessage += `\nTugas yang terdaftar saat ini:\n`;
            taskNames.slice(0, 5).forEach(name => {
                notFoundMessage += `- ${name}\n`;
            });
        }
        
        return conn.sendMessage(chatId, { 
          text: notFoundMessage 
        }, { quoted: msg });
      }

      // 4. Hapus Tugas dari Objek
      delete deadlines[foundTaskName];

      // 5. Simpan Database yang Diperbarui
      fs.writeFileSync(deadlinePath, JSON.stringify(deadlines, null, 2));

      // 6. Kirim Pesan Sukses
      return conn.sendMessage(chatId, { 
        text: `✅ *Tugas Berhasil Dihapus!*\n\nTugas: *${foundTaskName}* telah berhasil dihapus dari daftar deadline.` 
      }, { quoted: msg });

    } catch (err) {
      console.error("Error hapustugas:", err);
      return conn.sendMessage(chatId, { 
          text: `❌ *ERROR HAPUS TUGAS!* ❌\n\nTerjadi kesalahan saat mencoba menghapus tugas. Detail Error:\n${err.message}` 
      }, { quoted: msg });
    }
  }
};
