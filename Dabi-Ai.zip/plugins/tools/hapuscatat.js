import fs from "fs";
import path from "path";

// ⚠️ PASTIKAN 'dirname' terdefinisi di lingkungan Bot Anda!

export default {
    name: 'hapuscatat',
    command: ['hapuscatat', 'deletenote', 'removenote'],
    tags: 'Utilitas',
    desc: 'Menghapus catatan berdasarkan nomor urut dari list.',
    prefix: true,
    owner: false,

    run: async (conn, msg, { chatInfo, prefix, commandText, textMessage }) => {
        const { chatId } = chatInfo;
        const cmd = `${prefix}${commandText}`;
        const input = textMessage.slice(cmd.length).trim();
        
        // 🚨 Lokasi file JSON (sama dengan catat.js)
        const notesPath = path.join(dirname, "./db/notes.json");
        
        // --- Fungsi Baca/Tulis JSON ---
        const readNotes = () => {
            if (!fs.existsSync(notesPath)) {
                return {};
            }
            try {
                const data = fs.readFileSync(notesPath, 'utf-8');
                return JSON.parse(data);
            } catch (e) {
                console.error("Gagal membaca notes.json:", e);
                return {};
            }
        };

        const writeNotes = (notes) => {
            fs.writeFileSync(notesPath, JSON.stringify(notes, null, 2), 'utf-8');
        };

        // --- Validasi Input ---
        const indexToDelete = parseInt(input);

        if (isNaN(indexToDelete) || indexToDelete <= 0) {
            return conn.sendMessage(chatId, { text: `Tolong masukkan nomor urut catatan yang valid dari daftar. Contoh:\n${cmd} 3` }, { quoted: msg });
        }

        // --- Logika Penghapusan ---
        try {
            const notes = readNotes();
            const noteKeys = Object.keys(notes);

            if (noteKeys.length === 0) {
                return conn.sendMessage(chatId, { text: `⚠️ Saat ini tidak ada catatan tersimpan untuk dihapus.` }, { quoted: msg });
            }

            // Index dalam array dimulai dari 0, jadi kurangi 1
            const arrayIndex = indexToDelete - 1; 

            if (arrayIndex < 0 || arrayIndex >= noteKeys.length) {
                return conn.sendMessage(chatId, { text: `❌ Nomor *${indexToDelete}* tidak valid. Catatan hanya ada dari nomor 1 sampai ${noteKeys.length}.` }, { quoted: msg });
            }

            // Dapatkan judul catatan yang akan dihapus
            const titleToDelete = noteKeys[arrayIndex];
            
            // Hapus catatan dari objek notes
            delete notes[titleToDelete];

            // Tulis kembali data ke file JSON
            writeNotes(notes);

            let response = `🗑️ *Catatan Berhasil Dihapus!*`;
            response += `\n\n*Judul yang dihapus:* ${titleToDelete}`;
            
            return conn.sendMessage(chatId, { text: response }, { quoted: msg });

        } catch (error) {
            console.error('Error saat menghapus catatan:', error);
            return conn.sendMessage(chatId, { text: `Terjadi error pada sistem penghapusan: ${error.message}` }, { quoted: msg });
        }
    }
}
