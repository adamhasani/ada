import fs from "fs";
import path from "path";

// (Asumsi 'dirname' sudah di-setup di file ini, jika belum, Anda perlu menambahkannya)
// Contoh:
// import { fileURLToPath } from 'url';
// const __filename = fileURLToPath(import.meta.url);
// const dirname = path.dirname(__filename);

// Ganti path database agar khusus untuk deadline tugas
const deadlinePath = path.join(dirname, "../db/deadlines.json"); // Pastikan path ini benar, '../db' mungkin?

export default {
  name: "newtugas",
  command: ["newtugas", "tambahdeadline","tambah"],
  tags: "Tugas Menu",
  desc: "Tambah deadline tugas baru. Format: .newtugas [Nama Tugas] | [Tanggal YYYY-MM-DD] [Jam HH:MM] | [Deskripsi]",
  prefix: !0,
  owner: !1,
  premium: !1,

  run: async (conn, msg, {
    chatInfo,
    prefix,
    args
  }) => {
    const { chatId } = chatInfo;

    try {
      if (!fs.existsSync(deadlinePath)) fs.writeFileSync(deadlinePath, "{}");

      const deadlines = JSON.parse(fs.readFileSync(deadlinePath)),
            parts = args.join(" ").split("|").map(p => p.trim()),
            taskName = parts[0],
            dateTimeStr = parts[1], // Contoh: 2025-11-20 18:00
            description = parts[2] || '';
            
      // --- VALIDASI INPUT ---
      if (!taskName || !dateTimeStr) {
        return conn.sendMessage(chatId, { 
          text: `Format Salah!\nContoh: ${prefix}newtugas Tugas Matematika | 2025-11-20 18:00 | Kerjakan halaman 50.` 
        }, { quoted: msg });
      }

      if (deadlines[taskName]) { 
        return conn.sendMessage(chatId, { 
          text: `Tugas *${taskName}* sudah ada. Gunakan nama yang berbeda atau hapus yang lama.` 
        }, { quoted: msg });
      }
      
      const deadlineTime = new Date(dateTimeStr);
      if (isNaN(deadlineTime)) {
          return conn.sendMessage(chatId, { 
            text: `Format tanggal atau jam *${dateTimeStr}* tidak valid. Pastikan format: YYYY-MM-DD HH:MM.` 
          }, { quoted: msg });
      }
      
      // Cek apakah waktu deadline sudah lewat
      if (deadlineTime.getTime() < Date.now()) {
          return conn.sendMessage(chatId, {
            text: `Waktu deadline *${dateTimeStr}* sudah lewat. Masukkan waktu di masa depan.`
          }, { quoted: msg });
      }

      // --- SIMPAN DATA BARU (SUDAH DIPERBAIKI) ---
      deadlines[taskName] = {
        deadline: deadlineTime.toISOString(), // Simpan dalam format ISO
        description: description,
        addedBy: msg.key.remoteJid,
        
        // --- TAMBAHAN KRITIS ---
        chatId: chatId,         // Simpan ID grup tempat tugas ini dibuat
        remindedH24: false,     // Flag untuk pengingat H-1 (24 Jam)
        remindedH6: false,      // Flag untuk pengingat H-6 (6 Jam)
        remindedH1: false       // Flag untuk pengingat H-1 (1 Jam)
      };
      
      fs.writeFileSync(deadlinePath, JSON.stringify(deadlines, null, 2));

      // --- PESAN SUKSES ---
      const formattedDate = deadlineTime.toLocaleString('id-ID', { dateStyle: 'full', timeStyle: 'short' });
      return conn.sendMessage(chatId, { 
        text: `✅ Tugas baru berhasil ditambahkan:\n\n`
            + `*Nama:* ${taskName}\n`
            + `*Deadline:* ${formattedDate}\n`
            + (description ? `*Deskripsi:* ${description}\n` : '')
      }, { quoted: msg });

    } catch (err) {
      console.error("Error newtugas:", err);
      return conn.sendMessage(chatId, { text: `Error: Terjadi kesalahan saat menyimpan data tugas.` }, { quoted: msg });
    }
  }
};
