import fs from "fs";
import path from "path";

// ⚠️ PASTIKAN 'dirname' terdefinisi di lingkungan Bot Anda!

// Fungsi Helper untuk mendapatkan awal/akhir hari
const getStartOfDay = (date) => {
    const d = new Date(date);
    d.setHours(0, 0, 0, 0);
    return d;
};

const getEndOfDay = (date) => {
    const d = new Date(date);
    d.setHours(23, 59, 59, 999);
    return d;
};

export default {
    name: 'laporan',
    command: ['laporan', 'taskreport'],
    tags: 'Tugas Menu',
    desc: 'Menghasilkan laporan status tugas harian (Overdue, Jatuh Tempo Hari Ini, Mendatang).',
    prefix: true,
    owner: false,

    run: async (conn, msg, { chatInfo, prefix }) => {
        const { chatId } = chatInfo;
        const tasksPath = path.join(dirname, "./db/deadlines.json"); // Sesuaikan nama file jika perlu

        const readTasks = () => {
            if (!fs.existsSync(tasksPath)) return {};
            try {
                return JSON.parse(fs.readFileSync(tasksPath, 'utf-8'));
            } catch (e) {
                console.error("Gagal membaca tasks JSON:", e);
                return {};
            }
        };

        try {
            const tasks = readTasks();
            const now = Date.now();
            const startOfToday = getStartOfDay(now).getTime();
            const endOfToday = getEndOfDay(now).getTime();

            // Inisialisasi Kategori
            let dueTodayTasks = [];
            let overdueTasks = [];
            let upcomingTasks = [];
            let totalTasks = 0;

            for (const key in tasks) {
                const task = tasks[key];
                const deadlineTime = new Date(task.deadline).getTime();
                
                totalTasks++;

                if (deadlineTime < startOfToday) {
                    // 1. Tugas Overdue (Lewat sebelum 00:00 Hari Ini)
                    overdueTasks.push({ name: key, deadline: deadlineTime });
                } else if (deadlineTime <= endOfToday) {
                    // 2. Tugas Jatuh Tempo Hari Ini
                    dueTodayTasks.push({ name: key, deadline: deadlineTime });
                } else {
                    // 3. Tugas Mendatang (Setelah 23:59 Hari Ini)
                    upcomingTasks.push({ name: key, deadline: deadlineTime });
                }
            }
            
            // Urutkan tugas hari ini berdasarkan waktu deadline terdekat
            dueTodayTasks.sort((a, b) => a.deadline - b.deadline);


            if (totalTasks === 0) {
                return conn.sendMessage(chatId, { text: '✅ Laporan Tugas Harian: Tidak ada tugas aktif yang tercatat.' }, { quoted: msg });
            }

            // --- Format Laporan ---
            const todayName = new Date().toLocaleDateString('id-ID', { weekday: 'long' });
            let reportText = `📊 *LAPORAN TUGAS HARI INI (${todayName})*\n`;
            reportText += `_Update per: ${new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })}_\n\n`;
            reportText += `Total Tugas Aktif: ${totalTasks}\n`;
            reportText += `═══════════════════════\n\n`;

            // 1. Jatuh Tempo HARI INI
            reportText += `🔥 *JATUH TEMPO HARI INI (${dueTodayTasks.length} Tugas)*:\n`;
            if (dueTodayTasks.length > 0) {
                dueTodayTasks.forEach((t) => {
                    const time = new Date(t.deadline).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });
                    reportText += `   • ${time} WIB: ${t.name}\n`;
                });
                reportText += `\n`;
            } else {
                reportText += `   _Tidak ada tugas yang jatuh tempo Hari Ini. Selamat!_\n\n`;
            }

            // 2. Overdue
            reportText += `❌ *OVERDUE (${overdueTasks.length} Tugas)*:\n`;
            if (overdueTasks.length > 0) {
                overdueTasks.forEach((t, i) => reportText += `   • ${t.name}\n`);
                reportText += `\n`;
            } else {
                reportText += `   _Tidak ada tugas yang terlewat. Pertahankan!_\n\n`;
            }

            // 3. Mendatang (Upcoming)
            reportText += `✅ *MENDATANG (Tugas Sisa: ${upcomingTasks.length})*:\n`;
            if (upcomingTasks.length > 0) {
                // Tampilkan hanya tugas pertama di hari berikutnya
                const nextTask = upcomingTasks.sort((a, b) => a.deadline - b.deadline)[0];
                const nextDate = new Date(nextTask.deadline).toLocaleDateString('id-ID', { dateStyle: 'medium' });
                reportText += `   • Tugas berikutnya (${nextDate}): ${nextTask.name}\n`;
                reportText += `   _+ ${upcomingTasks.length - 1} tugas aktif lainnya..._\n`;
                reportText += `\n`;
            } else {
                reportText += `   _Semua tugas sudah diselesaikan atau terlewat._\n\n`;
            }
            
            reportText += `_Gunakan ${prefix}listtugas untuk detail lengkap._\n☕ Data Jelas, Kopi Tuntas! 📊`;

            return conn.sendMessage(chatId, { text: reportText }, { quoted: msg });

        } catch (error) {
            console.error('Error saat membuat laporan tugas:', error);
            return conn.sendMessage(chatId, { text: `Terjadi error saat membuat laporan: ${error.message}` }, { quoted: msg });
        }
    }
}
