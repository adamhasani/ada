import fs from "fs";
import path from "path";
import { fileURLToPath } from 'url';
import { dirname as pathDirname } from 'path';

// --- Mendefinisikan Lokasi Database yang Stabil ---
const __filename = fileURLToPath(import.meta.url);
const __dirname = pathDirname(__filename); 
const notesPath = path.join(__dirname, "../../db/notes.json"); 

// --- Fungsi Baca/Tulis JSON ---
const readNotes = () => {
    if (!fs.existsSync(notesPath)) {
        fs.writeFileSync(notesPath, JSON.stringify({}), 'utf-8');
        return {};
    }
    const data = fs.readFileSync(notesPath, 'utf-8');
    return JSON.parse(data);
};

const writeNotes = (notes) => {
    fs.writeFileSync(notesPath, JSON.stringify(notes, null, 2), 'utf-8');
};

// Handler utama plugin
export default {
    name: 'catat',
    command: ['catat', 'note', 'save', 'shownote', 'tampilkan', 'lihat', 'hapuscatat', 'delcatat'],
    tags: 'Utilitas',
    desc: 'Simpan: .catat [judul] | [isi]. Lihat: .lihat [nomor/judul]. Hapus: .hapuscatat [nomor/judul].',
    prefix: true,
    owner: false,

    run: async (conn, msg, { chatInfo, textMessage, prefix, commandText }) => {
        const { chatId } = chatInfo;
        const cmd = `${prefix}${commandText}`;
        const input = textMessage.slice(cmd.length).trim();
        
        const notes = readNotes();
        const noteKeys = Object.keys(notes);

        // --- A. Logika Perintah Hapus Catatan (.hapuscatat [nomor/judul]) ---
        if (['hapuscatat', 'delcatat'].includes(commandText)) {
            // ... (Logika ini tidak berubah)
            if (!input) {
                return conn.sendMessage(chatId, { text: `Mohon tentukan *nomor urut* catatan atau *judul* yang ingin dihapus. Contoh: *${prefix}hapuscatat 1*` }, { quoted: msg });
            }
            if (noteKeys.length === 0) {
                return conn.sendMessage(chatId, { text: `⚠️ Tidak ada catatan tersimpan untuk dihapus.` }, { quoted: msg });
            }
            let targetNoteKey;
            let index = parseInt(input.trim());
            const searchInput = input.toLowerCase().trim();
            if (!isNaN(index) && index > 0 && index <= noteKeys.length) {
                targetNoteKey = noteKeys[index - 1];
            } else {
                targetNoteKey = noteKeys.find(key => key.toLowerCase() === searchInput);
                if (!targetNoteKey) {
                    targetNoteKey = noteKeys.find(key => key.toLowerCase().includes(searchInput));
                }
            }
            if (!targetNoteKey) {
                return conn.sendMessage(chatId, { text: `❌ Catatan dengan nomor *${input}* atau judul tersebut tidak ditemukan.` }, { quoted: msg });
            }
            const deletedTitle = targetNoteKey; 
            delete notes[targetNoteKey];
            writeNotes(notes);
            return conn.sendMessage(chatId, { text: `✅ *Catatan berhasil dihapus!* \n\nJudul: *${deletedTitle}*` }, { quoted: msg });
        }
        
        
        // --- B. Logika Perintah Lihat Catatan Spesifik (.lihat [nomor/judul]) ---
        if (['lihat'].includes(commandText)) {
            // ... (Logika ini tidak berubah)
            if (!input) {
                return conn.sendMessage(chatId, { text: `Mohon tentukan nomor urut catatan atau judul/kata kunci yang ingin dilihat. Contoh:\n\n*${prefix}lihat 1*` }, { quoted: msg });
            }
            if (noteKeys.length === 0) {
                return conn.sendMessage(chatId, { text: `⚠️ Tidak ada catatan tersimpan untuk dilihat.` }, { quoted: msg });
            }
            let targetNoteKey;
            let index = parseInt(input.trim());
            const searchInput = input.toLowerCase().trim();
            if (!isNaN(index) && index > 0 && index <= noteKeys.length) {
                targetNoteKey = noteKeys[index - 1];
            } else {
                targetNoteKey = noteKeys.find(key => key.toLowerCase() === searchInput);
                if (!targetNoteKey) {
                    targetNoteKey = noteKeys.find(key => key.toLowerCase().includes(searchInput));
                }
            }
            if (!targetNoteKey) {
                return conn.sendMessage(chatId, { text: `❌ Catatan dengan nomor *${input}* atau judul yang mengandung teks tersebut tidak ditemukan.\n\nLihat semua catatan dengan: *${prefix}shownote*` }, { quoted: msg });
            }
            const targetNote = notes[targetNoteKey];
            let detailText = `📝 *DETAIL CATATAN* 📝\n\n`;
            detailText += `*Judul:* ${targetNoteKey}\n`;
            detailText += `*Tanggal:* ${new Date(targetNote.timestamp).toLocaleString('id-ID', { dateStyle: 'full', timeStyle: 'short' })}\n`;
            detailText += `*Dibuat oleh:* @${targetNote.senderId.split('@')[0]}\n\n`;
            detailText += `*Isi Lengkap Catatan:*\n\n${targetNote.content}`;
            return conn.sendMessage(chatId, { text: detailText, contextInfo: { mentionedJid: [targetNote.senderId] } }, { quoted: msg });
        }


        // --- C. Logika Perintah Tampilkan Semua Catatan (.shownote atau .tampilkan) ---
        // --- AWAL PERUBAHAN ---
        if (['shownote', 'tampilkan'].includes(commandText)) {
            if (noteKeys.length === 0) {
                return conn.sendMessage(chatId, { text: `⚠️ Saat ini tidak ada catatan tersimpan.` }, { quoted: msg });
            }

            let listText = "📝 *DAFTAR CATATAN TERSIMPAN* 📝\n\n";
            
            // Diubah: Hanya menampilkan nomor dan judul (key)
            noteKeys.forEach((key, index) => {
                listText += `*${index + 1}.* ${key}\n`; 
            });
            
            listText += `\nTotal: ${noteKeys.length} catatan.\n\n*Lihat detail:* ${prefix}lihat [nomor/judul]\n*Hapus catatan:* ${prefix}hapuscatat [nomor/judul]`;

            return conn.sendMessage(chatId, { text: listText }, { quoted: msg });
        }
        // --- AKHIR PERUBAHAN ---


        // --- D. Logika Perintah Catat (.catat, .note, .save) ---
        if (['catat', 'note', 'save'].includes(commandText)) {
            // ... (Logika ini tidak berubah)
            let contentToSave;
            let title;
            const quotedMsg = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
            
            if (quotedMsg) {
                contentToSave = 
                    quotedMsg.conversation || 
                    quotedMsg.extendedTextMessage?.text || 
                    quotedMsg.imageMessage?.caption ||
                    quotedMsg.videoMessage?.caption ||
                    `[Pesan non-teks: Tipe ${Object.keys(quotedMsg)[0]}]`; 
                if (input) {
                    title = input.trim();
                } else {
                    const rawTitle = contentToSave.substring(0, 30).trim();
                    title = `Catatan: ${rawTitle}`; 
                }
            } else if (input) {
                const parts = input.split('|');
                if (parts.length < 2) {
                    return conn.sendMessage(chatId, { text: `Format untuk menyimpan catatan baru salah.\n\n*Gunakan format:*\n${cmd} *[Judul Catatan]* | *[Isi Catatan]*\n\n*Atau balas pesan lalu ketik:*\n${cmd} *[Judul Catatan]*` }, { quoted: msg });
                }
                title = parts[0].trim();
                contentToSave = parts.slice(1).join('|').trim(); 
                if (!title || !contentToSave) {
                     return conn.sendMessage(chatId, { text: `Format salah. Judul dan Isi tidak boleh kosong.\nGunakan: *${cmd} [Judul] | [Isi]*` }, { quoted: msg });
                }
            } else {
                return conn.sendMessage(chatId, { text: `Tolong berikan input atau balas pesan.\n\n*Contoh 1 (Format Baru):*\n${cmd} *Daftar Belanja* | *Beras, Telur, Kopi*\n\n*Contoh 2 (Reply):*\n(Balas pesan) lalu ketik: ${cmd} *Catatan Penting*` }, { quoted: msg });
            }
            
            try {
                const now = new Date();
                let counter = 1;
                let finalTitle = title;
                while (notes[finalTitle]) {
                    finalTitle = `${title} (${counter++})`;
                }
                title = finalTitle; 
                notes[title] = {
                    content: contentToSave,
                    timestamp: now.toISOString(),
                    senderId: msg.key.participant || msg.key.remoteJid
                };
                writeNotes(notes);
                let response = `✅ *Catatan berhasil disimpan!*`;
                response += `\n\n*Judul:* ${title}\n*Konten:* ${contentToSave.substring(0, 100)}${contentToSave.length > 100 ? '...' : ''}`;
                return conn.sendMessage(chatId, { text: response }, { quoted: msg });
            } catch (error) {
                console.error('Error saat menyimpan catatan:', error);
                return conn.sendMessage(chatId, { text: `Terjadi error pada sistem penyimpanan: ${error.message}` }, { quoted: msg });
            }
        }
    }
}
