import fs from "fs";
import path from "path";

// ⚠️ PASTIKAN 'dirname' terdefinisi di lingkungan Bot Anda!

export default {
    name: 'caricatatan',
    command: ['caricatatan', 'findnote', 'searchnote'],
    tags: 'Utilitas',
    desc: 'Mencari catatan tersimpan berdasarkan kata kunci di judul atau isi.',
    prefix: true,
    owner: false,

    run: async (conn, msg, { chatInfo, textMessage, prefix, commandText }) => {
        const { chatId } = chatInfo;
        const cmd = `${prefix}${commandText}`;
        const keyword = textMessage.slice(cmd.length).trim();
        
        // 🚨 Lokasi file JSON
        const notesPath = path.join(dirname, "./db/notes.json");
        
        // --- Cek Input dan File ---
        if (!keyword) {
            return conn.sendMessage(chatId, { text: `Tolong masukkan kata kunci untuk dicari. Contoh:\n${cmd} Rapat Penting` }, { quoted: msg });
        }
        
        if (!fs.existsSync(notesPath)) {
            return conn.sendMessage(chatId, { text: `⚠️ Database catatan (${notesPath}) tidak ditemukan atau kosong.` }, { quoted: msg });
        }
        
        // --- Fungsi Baca JSON ---
        const readNotes = () => {
            try {
                const data = fs.readFileSync(notesPath, 'utf-8');
                return JSON.parse(data);
            } catch (e) {
                console.error("Gagal membaca notes.json:", e);
                return {};
            }
        };

        // --- Logika Pencarian ---
        try {
            const notes = readNotes();
            const noteKeys = Object.keys(notes);
            const lowerKeyword = keyword.toLowerCase();
            let foundNotes = {};

            // Loop melalui setiap catatan untuk mencari kata kunci
            noteKeys.forEach((key) => {
                const note = notes[key];
                
                // Cek kata kunci di Judul dan Konten
                const titleMatch = key.toLowerCase().includes(lowerKeyword);
                const contentMatch = note.content.toLowerCase().includes(lowerKeyword);

                if (titleMatch || contentMatch) {
                    foundNotes[key] = note;
                }
            });

            const foundKeys = Object.keys(foundNotes);

            if (foundKeys.length === 0) {
                return conn.sendMessage(chatId, { text: `🧐 Tidak ditemukan catatan yang mengandung kata kunci "*${keyword}*".` }, { quoted: msg });
            }

            // --- Format Hasil Pencarian ---
            let listText = `🔍 *HASIL PENCARIAN* (Kata kunci: "*${keyword}*")\n\n`;
            
            foundKeys.forEach((key, index) => {
                const note = foundNotes[key];
                listText += `*${index + 1}. Judul:* ${key}\n`;
                
                // Tampilkan potongan konten yang relevan
                const snippet = note.content.substring(0, 150);
                listText += `   *Konten:* ${snippet}${note.content.length > 150 ? '...' : ''}\n`;
                
                // Tambahkan marker jika keyword ditemukan di judul
                listText += `   *Relevansi:* ${key.toLowerCase().includes(lowerKeyword) ? 'Judul & Isi' : 'Isi'}\n`;
                listText += `\n`;
            });
            listText += `\nTotal: ${foundKeys.length} catatan ditemukan.`;

            return conn.sendMessage(chatId, { text: listText }, { quoted: msg });

        } catch (error) {
            console.error('Error saat melakukan pencarian catatan:', error);
            return conn.sendMessage(chatId, { text: `Terjadi error saat mencari data: ${error.message}` }, { quoted: msg });
        }
    }
}
