import fetch from 'node-fetch'
import { convertToWebp, sendImageAsSticker } from '../../toolkit/exif.js'

export default {
  name: 'emojimix',
  command: ['emojimix', 'mix'],
  tags: 'Tools Menu',
  desc: 'Gabungkan dua emoji dan kirim sebagai stiker',
  prefix: !0,
  owner: !1,
  premium: !1,

  run: async (conn, msg, {
    chatInfo,
    textMessage, // Kita akan menggunakan ini (atau 'body')
    body,
    args,
    prefix,
    commandText
  }) => {
    const { chatId } = chatInfo

    // Gunakan variabel mana saja yang berisi teks (utamakan 'body' atau 'textMessage')
    const rawText = body || textMessage || ""; 
    
    // 1. Ambil seluruh teks setelah command (misal: "😭😂" or "😭 😂")
    const inputText = rawText.slice(prefix.length + commandText.length).trim();
    
    // --- 🚨 LOGIKA PARSING BARU ---
    // 2. Pisahkan string menjadi array karakter/emoji (graphemes)
    //    Ini akan mengubah "😭😂" menjadi ['😭', '😂']
    //    Ini juga akan mengubah "😭 😂" menjadi ['😭', ' ', '😂']
    const graphemes = [...inputText];

    // 3. Filter (buang) spasi dari array
    const emojiArgs = graphemes.filter(char => char.trim() !== '');
    // --- AKHIR LOGIKA PARSING BARU ---

    
    // 4. Cek jumlah argumen (emoji)
    if (emojiArgs.length < 2 || !emojiArgs[0] || !emojiArgs[1]) {
      // Kita perbarui pesan errornya untuk menjelaskan format baru
      return conn.sendMessage(chatId, { text: `Contoh penggunaan:\n${prefix}${commandText} 😭😂 (Boleh disambung atau dipisah spasi)` }, { quoted: msg })
    }

    try {
      const emoji1 = emojiArgs[0],
            emoji2 = emojiArgs[1],
            // URL API (Google/Tenor)
            url = `https://tenor.googleapis.com/v2/featured?key=AIzaSyC-P6_qz3FzCoXGLk6tgitZo4jEJ5mLzD8&contentfilter=high&media_filter=png_transparent&component=proactive&collection=emoji_kitchen_v5&q=${encodeURIComponent(emoji1)}_${encodeURIComponent(emoji2)}`,
            res = await fetch(url),
            data = await res.json(),
            results = data?.results || []

      if (!results.length)
        return conn.sendMessage(chatId, { text: 'Kombinasi emoji tidak didukung.' }, { quoted: msg })

      for (const i of results) {
        const imgUrl = i?.url || i?.media_formats?.png_transparent?.url
        if (!imgUrl) continue

        const imgBuffer = await (await fetch(imgUrl)).arrayBuffer(),
              webpBuffer = await convertToWebp(Buffer.from(imgBuffer))

        await sendImageAsSticker(conn, chatId, webpBuffer, msg)
      }
    } catch (err) {
      console.error('Error emojimix:', err),
      conn.sendMessage(chatId, { text: 'Terjadi kesalahan saat membuat emoji mix.' }, { quoted: msg })
    }
  }
}
