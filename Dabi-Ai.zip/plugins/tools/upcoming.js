import fs from "fs";
import path from "path";

// Pastikan path database sama dengan yang digunakan di plugin lain
const deadlinePath = path.join(dirname, "./db/deadlines.json");
// Konstanta untuk filter: 7 hari dalam milidetik
const MS_IN_7_DAYS = 7 * 24 * 60 * 60 * 1000; 

// Fungsi helper yang sama untuk menghitung dan memformat sisa waktu
function formatTimeRemaining(ms) {
    const totalSeconds = Math.floor(ms / 1000);
    const totalMinutes = Math.floor(totalSeconds / 60);
    const totalHours = Math.floor(totalMinutes / 60);
    const days = Math.floor(totalHours / 24);
    
    const hours = totalHours % 24; 
    const minutes = totalMinutes % 60; 

    let output = '';
    if (days > 0) {
        output += `${days} hari`;
    }
    if (hours > 0) {
        if (output) output += ', ';
        output += `${hours} jam`;
    }
    if (minutes > 0 && days === 0) {
        if (output) output += ', ';
        output += `${minutes} menit`;
    }
    
    if (output === '' && totalSeconds > 0) {
        return `${totalMinutes} menit`;
    }
    
    return output || 'Kurang dari 1 menit';
}

export default {
  name: "upcoming",
  command: ["upcoming", "tugasdekat", "urgentlist","dekat"],
  tags: "Tugas Menu", 
  desc: "Menampilkan daftar tugas yang deadlinenya dalam 7 hari ke depan.",
  prefix: !0,
  owner: !1, 
  premium: !1,

  run: async (conn, msg, {
    chatInfo,
    prefix
  }) => {
    const { chatId } = chatInfo;
    
    try {
      if (!fs.existsSync(deadlinePath)) {
        return conn.sendMessage(chatId, { 
          text: `⚠️ *Database Tugas Belum Ditemukan!*\n\nMohon tambahkan tugas terlebih dahulu menggunakan *${prefix}newtugas*.` 
        }, { quoted: msg });
      }

      const data = fs.readFileSync(deadlinePath);
      let deadlines;
      
      try {
          deadlines = JSON.parse(data);
      } catch (e) {
          return conn.sendMessage(chatId, { text: `❌ *ERROR PARSING DATA!* Database tugas rusak.` }, { quoted: msg });
      }
      
      const taskNames = Object.keys(deadlines);
      const now = new Date();
      
      // 1. Ubah objek menjadi array dan Filter Tugas yang Akan Datang
      const tasksArray = taskNames
        .map(name => ({ name, ...deadlines[name] }))
        .filter(task => {
            const deadlineTime = new Date(task.deadline).getTime();
            const diffMs = deadlineTime - now.getTime();
            
            // Tugas harus belum kedaluwarsa (diffMs > 0) DAN dalam 7 hari ke depan
            return diffMs > 0 && diffMs <= MS_IN_7_DAYS;
        });

      // 2. Cek apakah ada tugas yang mendesak
      if (tasksArray.length === 0) {
        return conn.sendMessage(chatId, { 
          text: `😎 Tidak ada tugas yang jatuh tempo dalam 7 hari ke depan. Santai sejenak!` 
        }, { quoted: msg });
      }

      // 3. Urutkan (Paling Mendesak di atas)
      tasksArray.sort((a, b) => new Date(a.deadline) - new Date(b.deadline));
      
      let listText = "🔥 *TUGAS MENDESAK (Deadline 7 Hari Ke Depan)* 🔥\n\n";
      
      tasksArray.forEach((task, index) => {
          const deadlineDate = new Date(task.deadline);
          const timeDifferenceMs = deadlineDate.getTime() - now.getTime();
          
          const formattedDate = deadlineDate.toLocaleString('id-ID', { 
              day: 'numeric', 
              month: 'long', 
              year: 'numeric' 
          });

          const countdownText = `*Sisa:* ${formatTimeRemaining(timeDifferenceMs)}`;

          // --- Format Output ---
          listText += `*${index + 1}. ${task.name}* 🔔\n`;
          listText += `   *Waktu:* ${formattedDate} (${countdownText})\n`;
          
          if (task.description) {
              listText += `   *Deskripsi:* ${task.description.substring(0, 50)}${task.description.length > 50 ? '...' : ''}\n`;
          }
          listText += `\n`; 
      });

      listText += `\n_Total ${tasksArray.length} tugas mendesak._\n`;
      
      return conn.sendMessage(chatId, { 
        text: listText 
      }, { quoted: msg });

    } catch (err) {
      console.error("Error upcoming:", err);
      return conn.sendMessage(chatId, { 
          text: `❌ *ERROR MUNCUL!* Terjadi kesalahan saat memproses data tugas. Detail Error:\n${err.message}` 
      }, { quoted: msg });
    }
  }
};
