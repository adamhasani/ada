// File: owner.js (Perbaikan VCard Tidak Bisa Diklik)

export default {
  name: 'owner',
  command: ['owner', 'contact', 'admin'],
  tags: 'Info Menu',
  desc: 'Mengirim kontak owner bot',
  prefix: !0,
  owner: !1,

  run: async (conn, msg, {
    chatInfo
  }) => {
    try {
      const { chatId } = chatInfo,
            // 💡 Nama Anda ("Sains Data Ai") sudah benar diambil dari global.ownerName
            owner = global.ownerName || 'Owner Utama', 
            bot = global.botName || 'Bot',
            ownerNumbers = Array.isArray(global.contact) ? global.contact : [global.contact]

      if (!ownerNumbers || !ownerNumbers.length) return conn.sendMessage(chatId, { text: 'Kontak owner tidak tersedia saat ini.' }, { quoted: msg })

      // --- 🚨 PERBAIKAN FORMAT VCARD DI SINI 🚨 ---
      const contactsArray = ownerNumbers.map((num, i) => {
          const displayName = `${owner} ${ownerNumbers.length > 1 ? i + 1 : ''}`.trim();
          
          // Ini adalah format yang benar agar tombol "Kirim pesan" muncul
          const vcard = `BEGIN:VCARD\n` + 
                        `VERSION:3.0\n` + 
                        `FN:${displayName}\n` + // Nama Lengkap
                        // WAJIB menggunakan format +NOMOR (misal +628...)
                        `TEL;type=CELL;type=VOICE;waid=${num}:+${num}\n` + 
                        `END:VCARD`;

          return { vcard, displayName };
      });
      
      const finalDisplayName = ownerNumbers.length > 1 
          ? `${owner} (${ownerNumbers.length} Kontak)` 
          : contactsArray[0].displayName;

      // HANYA MENGIRIM VCARD
      await conn.sendMessage(chatId, { 
          contacts: { 
              displayName: finalDisplayName, 
              contacts: contactsArray.map(c => ({ vcard: c.vcard })) // Kirim hanya vcard string
          } 
      }, { quoted: msg });
      
      // (Pesan teks kedua sudah dihapus sesuai permintaan Anda sebelumnya)

    } catch (e) { console.error('Terjadi kesalahan di plugin owner:', e) }
  }
}
