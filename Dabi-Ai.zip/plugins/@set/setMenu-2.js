import axios from 'axios';

// 🚨 PERBAIKAN UTAMA: Pastikan thumbnail diset ke string kosong jika tidak ada gambar
const thumbnail = ''; // Biarkan kosong jika Mode 3 aktif!

// Asumsi variabel global lain (footer, botFullName, etc.) sudah didefinisikan.
const footer = global.footer || 'Mas Ngopi Data'; 
const botFullName = global.botFullName || 'Mas Ngopi';


export default {
  run: async (conn, msg, { chatInfo }, menuText) => {
    
    // Nonaktifkan fungsi ini jika thumbnail kosong
    let thumbnailBuffer = null;
    if (thumbnail) {
        const downloadImage = async (url) => {
          try {
            const res = await axios.get(url, { responseType: "arraybuffer" });
            return Buffer.from(res.data, "binary");
          } catch {
            return null;
          }
        };
        thumbnailBuffer = await downloadImage(thumbnail);
    }

    // --- LOGIKA PENGIRIMAN PESAN UTAMA ---
    
    // 💡 JIKA TIDAK ADA THUMBNAIL, KIRIM SEBAGAI TEKS BIASA SAJA UNTUK MENGHINDARI CRASH
    if (!thumbnail || !thumbnailBuffer) {
        // Fallback ke Teks Sederhana (Ini adalah intisari dari setMenu-3.js)
        await conn.sendMessage(chatInfo.chatId, { text: menuText }, { quoted: msg });
        return; // Hentikan fungsi di sini
    }


    // 💡 Jika ada Thumbnail (Mode 2 aktif dan berjalan normal)
    const documentMessage = {
        document: { url: thumbnail },
        mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
        fileName: "≡ 𝐌𝐄𝐍𝐔",
        fileLength: 1,
        jpegThumbnail: thumbnailBuffer,
        caption: menuText,
        footer: footer,
        contextInfo: {
          forwardingScore: 999,
          isForwarded: !0,
          externalAdReply: {
            body: `Ini Menu ${botFullName}`,
            thumbnailUrl: thumbnail,
            thumbnail: thumbnailBuffer,
            mediaType: 1,
            renderLargerThumbnail: !0,
            // mediaUrl dan Channel info diabaikan
          },
        },
    };

    await conn.sendMessage(chatInfo.chatId, documentMessage, { quoted: msg });
  }
};
