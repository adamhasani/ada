import { GoogleGenerativeAI, HarmCategory, HarmBlockThreshold } from "@google/generative-ai";
import stg from "./setting.js"; // Mengambil setting dari folder yang sama

// --------------------------------------------------------------------------------
// PENTING:
// Anda HARUS menambahkan API Key Gemini Anda di file ./toolkit/setting.js
// Contoh di setting.js:
// ...
// apiKeys: {
//   gemini: "API_KEY_ANDA_TARUH_DISINI"
// },
// ...
// --------------------------------------------------------------------------------
const API_KEY = stg.apiKeys?.gemini;

if (!API_KEY) {
  console.log(chalk.redBright.bold("API Key Gemini tidak ditemukan di setting.js. Modul AI tidak akan berjalan."));
}

const genAI = new GoogleGenerativeAI(API_KEY);

// Konfigurasi keamanan dasar
const safetySettings = [
  {
    category: HarmCategory.HARM_CATEGORY_HARASSMENT,
    threshold: HarmBlockThreshold.BLOCK_NONE,
  },
  {
    category: HarmCategory.HARM_CATEGORY_HATE_SPEECH,
    threshold: HarmBlockThreshold.BLOCK_NONE,
  },
  {
    category: HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT,
    threshold: HarmBlockThreshold.BLOCK_NONE,
  },
  {
    category: HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT,
    threshold: HarmBlockThreshold.BLOCK_NONE,
  },
];

/**
 * Menghasilkan respons dari model Gemini.
 * @param {string} text - Teks input dari pengguna.
 * @returns {Promise<string>} - Respons yang dihasilkan AI.
 */
const gemini = async (text) => {
  if (!API_KEY) {
    return "Maaf, API Key Gemini belum diatur oleh Owner.";
  }

  try {
    const model = genAI.getGenerativeModel({ 
      model: "gemini-1.5-flash-latest", // Model terbaru yang cepat
      safetySettings 
    });

    const result = await model.generateContent(text);
    const response = await result.response;
    const responseText = response.text();
    
    return responseText;

  } catch (error) {
    console.error(chalk.redBright.bold("[Gemini AI Error]"), error);
    return "Maaf, terjadi kesalahan saat mencoba menghubungi AI Gemini.";
  }
};

// Ekspor fungsi agar bisa dipakai di main.js
export default {
  gemini
};
