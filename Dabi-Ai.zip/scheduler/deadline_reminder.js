import fs from "fs";
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';        

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename); 

// --- PERBAIKAN PATH DATABASE ---
// Path diubah untuk mengarah ke toolkit/db/deadlines.json
const deadlinePath = join(__dirname, "../toolkit/db/deadlines.json"); 

// KEMBALI KE NILAI NORMAL: Menggunakan 7 hari untuk pengumuman
const MS_IN_7_DAYS = 7 * 24 * 60 * 60 * 1000; 
const MS_IN_8_DAYS = 8 * 24 * 60 * 60 * 1000; // Rentang 7-8 hari
const ZWS = '\u200b'; 

// Fungsi helper (Wajib ada di sini untuk menghindari masalah impor)
function formatTimeRemaining(ms) {
    const totalMinutes = Math.floor(ms / (1000 * 60));
    const totalHours = Math.floor(totalMinutes / 60);
    const days = Math.floor(totalHours / 24);
    
    const hours = totalHours % 24; 
    const minutes = totalMinutes % 60; 

    let output = '';
    if (days > 0) output += `${days} hari`;
    if (hours > 0) output += (output ? ', ' : '') + `${hours} jam`;
    if (minutes > 0) output += (output ? ', ' : '') + `${minutes} menit`;
    
    return output || 'Kurang dari 1 menit';
}

/**
 * Fungsi utama checker. Sekarang berfungsi sebagai pengirim notifikasi H-7 hari.
 */
export default async function deadlineChecker(conn, getMetadata) {
    if (!fs.existsSync(deadlinePath)) return;

    try {
        const data = fs.readFileSync(deadlinePath);
        let deadlines = JSON.parse(data);
        const taskNames = Object.keys(deadlines);
        const now = new Date();
        let updatedDeadlines = { ...deadlines };
        let hasChanges = false;
        
        // 1. Filter Tugas yang Akan Datang (7 hari)
        const tasksToAnnounce = taskNames
            .map(name => ({ name, ...deadlines[name] }))
            .filter(task => {
                const deadlineTime = new Date(task.deadline).getTime();
                const diffMs = deadlineTime - now.getTime();
                
                // Tugas harus belum kedaluwarsa (diffMs > 0)
                // DAN dalam rentang 7-8 hari ke depan
                // DAN belum pernah diingatkan
                return diffMs > 0 
                    && diffMs <= MS_IN_7_DAYS
                    && !task.reminded_h7d;
            });
            
        if (tasksToAnnounce.length === 0) {
            console.log('[SCHEDULER] Tidak ada tugas yang memerlukan pengumuman H-7 hari.');
            return;
        }

        // 2. Jika ada tugas, proses pengumuman per grup/chat
        for (const task of tasksToAnnounce) {
            const chatId = task.addedBy;
            const deadlineTime = new Date(task.deadline).getTime();
            const diffMs = deadlineTime - now.getTime();
            
            console.log(`\n[ATTEMPT-H7D] Mencoba kirim notif untuk tugas: ${task.name} di ${chatId}`);

            try {
                // Hanya umumkan jika chat adalah grup
                if (chatId.endsWith('@g.us')) {
                    // Ambil daftar peserta grup (getMetadata)
                    const meta = await getMetadata(chatId, conn);
                    const participantsToMention = meta.participants.map(p => p.id);
                    
                    // Buat Teks Pengumuman
                    const formattedDate = new Date(task.deadline).toLocaleString('id-ID', { dateStyle: 'full', timeStyle: 'short' });
                    const countdownText = formatTimeRemaining(diffMs);

                    let listText = "🚨 *PERINGATAN DEADLINE OTOMATIS (H-7 HARI)!* 🚨\n\n";
                    listText += `*1. ${task.name}*\n`;
                    listText += `   🗓️ Deadline: ${formattedDate} (Sisa: ${countdownText})\n`;
                    listText += `   📋 Deskripsi: ${task.description || '-'}\n\n`;

                    // 3. Kirim pesan pengumuman (tanpa tag)
                    await conn.sendMessage(chatId, { text: listText });

                    // 4. Kirim pesan Hidetag
                    if (participantsToMention.length > 0) {
                        await conn.sendMessage(chatId, {
                            text: ZWS, 
                            mentions: participantsToMention 
                        });
                    }
                    
                    console.log(`[SUCCESS-H7D] Sukses kirim notif untuk tugas: ${task.name}`);
                    
                    // 5. Tandai tugas agar tidak diingatkan lagi
                    updatedDeadlines[task.name].reminded_h7d = true;
                    hasChanges = true;

                } else {
                    // Kirim pesan biasa jika bukan grup (Opsional)
                    // ...
                    
                    updatedDeadlines[task.name].reminded_h7d = true;
                    hasChanges = true;
                }

            } catch (e) {
                console.error(`[FAIL-SENDING-H7D] Gagal kirim pesan untuk ${task.name} di ${chatId}: ${e.message}`);
                // Lanjutkan ke tugas berikutnya meskipun gagal kirim
            }
        }

        // 6. Penghapusan tugas kadaluarsa (lebih dari 8 hari)
        for (const taskName in deadlines) {
             const diffMs = new Date(deadlines[taskName].deadline).getTime() - now.getTime();
             if (diffMs < -MS_IN_8_DAYS) { 
                 delete updatedDeadlines[taskName];
                 hasChanges = true;
             }
         }


        if (hasChanges) {
            fs.writeFileSync(deadlinePath, JSON.stringify(updatedDeadlines, null, 2));
        }

    } catch (err) {
        console.error(`[SCHEDULER-CRASH] Error di fungsi utama: ${err.message}`);
    }
}