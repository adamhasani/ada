import fs from "fs";
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';        

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename); 

const GRUP_TARGET = [
    // '12036304xxxxxx@g.us', 
]; 

const KUTIPAN = [
    "Cara terbaik untuk memulai adalah dengan berhenti berbicara dan mulai melakukan. - Walt Disney",
    "Orang-orang pesimis melihat kesulitan di setiap kesempatan. Orang-orang optimis melihat kesempatan di setiap kesulitan. - Winston Churchill",
    "Jangan biarkan hari kemarin menyita terlalu banyak hari ini. - Will Rogers",
    "Satu-satunya sumber pengetahuan adalah pengalaman. - Albert Einstein",
    "Sukses bukanlah akhir, kegagalan bukanlah fatal: yang terpenting adalah keberanian untuk melanjutkan. - Winston Churchill",
    "Masa depan adalah milik mereka yang percaya pada keindahan impian mereka. - Eleanor Roosevelt",
    "Tindakan adalah kunci dasar untuk semua kesuksesan. - Pablo Picasso",
    "Kurang cerdas dapat diperbaiki dengan belajar, kurang cakap dapat dihilangkan dengan pengalaman. Namun tidak jujur itu sulit diperbaiki. - Bung Hatta",
    "Perjalanan seribu mil dimulai dengan satu langkah. - Lao Tzu",
    "Hidup adalah 10% apa yang terjadi pada kita dan 90% bagaimana kita menanggapinya. - Charles R. Swindoll",
    "Bermimpilah setinggi langit. Jika engkau jatuh, engkau akan jatuh di antara bintang-bintang. - Soekarno",
    "Tantangan adalah yang membuat hidup menarik; mengatasinya adalah yang membuat hidup bermakna. - Joshua J. Marine",
    "Ubahlah pikiranmu dan kamu akan mengubah duniamu. - Norman Vincent Peale",
    "Satu-satunya cara untuk melakukan pekerjaan hebat adalah dengan mencintai apa yang Anda lakukan. - Steve Jobs",
    "Kesuksesan seringkali datang kepada mereka yang berani bertindak. - B.J. Habibie",
    "Percaya kamu bisa dan kamu sudah setengah jalan. - Theodore Roosevelt",
    "Pendidikan adalah senjata paling ampuh yang bisa kamu gunakan untuk mengubah dunia. - Nelson Mandela",
    "Jangan takut gagal. Ketakutan terbesar adalah sukses dalam hal-hal yang tidak penting dalam hidup. - Corrie ten Boom",
    "Jika Anda tidak menyukai sesuatu, ubahlah. Jika Anda tidak bisa mengubahnya, ubahlah sikap Anda. - Maya Angelou",
    "Orang yang tidak pernah membuat kesalahan adalah orang yang tidak pernah mencoba sesuatu yang baru. - Albert Einstein"
];

let lastSent = 0; 

export default async function morningMotivationChecker(conn, getMetadata) {
    const now = new Date();
    const currentHour = now.getHours();
    const currentDate = now.toISOString().split('T')[0];

    // Hanya kirim jika jam 7 pagi DAN belum pernah dikirim hari ini
    if (currentHour !== 7 || lastSent === currentDate) {
        return; 
    }

    try {
        const kutipanAcak = KUTIPAN[Math.floor(Math.random() * KUTIPAN.length)];
        const message = `☀️ *Selamat Pagi!* ☀️\n\nSemoga harimu menyenangkan.\n\n*Kutipan Hari Ini:*\n_"${kutipanAcak}"_`;

        let targetChats = [];

        if (GRUP_TARGET.length > 0) {
            targetChats = GRUP_TARGET;
        } else {
            const db = getDB(); 
            targetChats = Object.keys(db.Grup || {}); 
        }

        for (const chatId of targetChats) {
            if (chatId.endsWith('@g.us')) {
                try {
                    // 🚨 TITIK RAWAN CRASH 🚨
                    await conn.sendMessage(chatId, { text: message });
                } catch (e) {
                    console.error(`[MOTIVASI-FAIL] Gagal kirim ke ${chatId}: ${e.message}`);
                }
            }
        }
        
        lastSent = currentDate; 
    } catch (err) {
        console.error(`[MOTIVASI-CRASH] Error di fungsi utama: ${err.message}`);
    }
}
